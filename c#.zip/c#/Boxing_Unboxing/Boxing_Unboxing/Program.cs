﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Boxing_Unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            //boxing & unboxing
            int i = 10;
            Object obj = i; //boxing
            Console.Write(obj);
            int j = (int)obj; //unboxing
            Console.Write(j);
            Console.Read();
        }
    }
}
