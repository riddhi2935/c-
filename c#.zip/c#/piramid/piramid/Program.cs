﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace piramid
{
    class Program
    {
        static void Main(string[] args)
        {
            //1 
            //2 3
            //6 18 108...N
            Console.Write("enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());
            int i=1, k=1, old=0, New=0, temp=0;
            do
            {
                int j=1;
                do
                {
                    if(k<=3)
                    {
                        Console.Write(k);
                        New=k;
                        old=k-1;
                    }
                    else
                    {
                        temp=old*New;
                        if(temp>n)
                        {
                            break;
                        }
                        Console.Write(temp);
                        old=New;
                        New=temp;
                    }
                    k++;
                    j++;
                }while(j<=i);
                if(temp>n)
                {
                    break;
                }
                Console.WriteLine();
                i++;
            }while(i<=n);
            Console.Read();
        }
    }
}
